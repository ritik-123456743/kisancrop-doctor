CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL,
    mobile VARCHAR(15) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    village VARCHAR(100),
    district VARCHAR(100),
    state VARCHAR(100),
    pincode VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS crops (
    crop_id INTEGER PRIMARY KEY AUTOINCREMENT,
    crop_name VARCHAR(100) NOT NULL,
    crop_name_hi VARCHAR(100) NOT NULL,
    season VARCHAR(50),
    water_need VARCHAR(50),
    soil_types TEXT
);

CREATE TABLE IF NOT EXISTS diseases (
    disease_id VARCHAR(100) PRIMARY KEY,
    crop_id INTEGER,
    disease_name VARCHAR(150) NOT NULL,
    disease_name_hi VARCHAR(150) NOT NULL,
    symptoms TEXT,
    cause TEXT,
    organic_treatment TEXT,
    chemical_treatment TEXT,
    prevention TEXT,
    severity_level VARCHAR(20),
    FOREIGN KEY (crop_id) REFERENCES crops(crop_id)
);

CREATE TABLE IF NOT EXISTS scan_records (
    scan_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    crop_id INTEGER,
    image_path TEXT NOT NULL,
    predicted_disease_id VARCHAR(100),
    confidence REAL,
    scan_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS soil_reports (
    soil_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    soil_type VARCHAR(50),
    ph_value REAL,
    water_source VARCHAR(50),
    previous_crop VARCHAR(100),
    farm_size_acres REAL,
    recommended_crop TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

INSERT OR IGNORE INTO crops (crop_id, crop_name, crop_name_hi, season, water_need, soil_types) VALUES 
(1, 'Tomato', 'टमाटर', 'Kharif/Rabi', 'Moderate', 'Domat, Kali, Matiyari'),
(2, 'Potato', 'आलू', 'Rabi', 'High', 'Domat, Balu'),
(3, 'Rice', 'धान', 'Kharif', 'Very High', 'Matiyar, Domat'),
(4, 'Wheat', 'गेहूं', 'Rabi', 'Moderate', 'Domat, Balu');
