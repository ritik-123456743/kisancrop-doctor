# KisanCropDoctor - किसान क्रॉप डॉक्टर
**"फोटो डालो, फसल बचाओ" (Snap Photo, Save Your Harvest)**

AI-powered crop disease detection, soil advisory, and agricultural treatment guide for Indian farmers.

---

## 📁 प्रोजेक्ट स्ट्रक्चर (Project Structure)
```
KisanCropDoctor/
├── app.py                         # Python Flask Backend with AI Vision
├── train_plantvillage_mobilenet.py# MobileNetV2 224x224 CNN Training Script
├── schema.sql                     # SQLite/MySQL Database Schema
├── requirements.txt               # Python Dependencies
├── model/
│   └── class_names.json          # 38 PlantVillage Dataset Disease Classes
├── static/
│   └── uploads/                  # Uploaded leaf photos folder
├── package.json                   # Full-Stack React + Express configuration
├── server.ts                      # Express API proxy + Gemini 3.8 Flash Vision
└── src/                           # Frontend React application
```

---

## 🚀 लोकल मशीन पर कैसे चलाएं (How to Run Locally)

### Option 1: Python Flask Backend (जैसा आपने मांगा था)
```bash
# 1. निर्भरताएं (dependencies) इंस्टॉल करें
pip install -r requirements.txt

# 2. डेटाबेस बनाएं (Database Initialize)
python -c "import sqlite3; conn = sqlite3.connect('kisan_crop_doctor.db'); conn.executescript(open('schema.sql', encoding='utf-8').read()); print('Database ready!')"

# 3. AI मॉडल ट्रेन करें (वैकल्पिक यदि मॉडल तैयार है)
python train_plantvillage_mobilenet.py

# 4. फ्लास्क सर्वर चलाएं
python app.py
```
ब्राउज़र में खोलें: `http://localhost:5000`

---

### Option 2: Full-Stack React + Node (AI Studio Edition)
```bash
npm install
npm run dev
```
ब्राउज़र में खोलें: `http://localhost:3000`

---

## 🌾 मुख्य फीचर्स (Key Features)
1. **रोग स्कैनर**: पत्ती की फोटो अपलोड करके रोग, लक्षण, जैविक (नीम तेल/ट्राइकोडर्मा) व रासायनिक उपचार की पहचान।
2. **स्प्रे पंप कैलकुलेटर**: 15L हाथ पंप, 16L बैटरी पंप, 20L पंप के लिए सटीक खुराक।
3. **मिट्टी सलाहकार**: रेत, दोमट, मटियारी, बलुई, काली मिट्टी व pH अनुसार उपयुक्त फसल।
4. **मौसम अलर्ट**: नमी 75% से अधिक होने पर झुलसा (Blight) का अलर्ट।
5. **खेत डायरी**: स्कैन इतिहास व 7 दिन बाद की सुधार फोटो तुलना।
6. **बोलकर सुनें (Voice Audio 🔊)**: रिपोर्ट को हिंदी आवाज में सुनने की सुविधा।
